
local _, KkthnxUIActionbars = ...
local cfg = KkthnxUIActionbars.Config

PossessBarFrame:SetScale(cfg.possessBar.scale)
PossessBarFrame:SetAlpha(cfg.possessBar.alpha)
