
local _, KkthnxUIActionbars = ...
local cfg = KkthnxUIActionbars.Config

MultiBarBottomLeft:SetAlpha(cfg.multiBarBottomLeft.alpha)
